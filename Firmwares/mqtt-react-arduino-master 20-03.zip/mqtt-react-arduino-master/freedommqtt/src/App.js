import React from 'react';
import './App.css';
import Mqtt from '../src/componentes/mqtt'
import Home from '../src/componentes/home'

function App() {
  return (
    <div className="App">
      <Home />
    </div>
  );
}

export default App;
